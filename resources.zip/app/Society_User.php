<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Society_User extends Model
{
    protected $table = 'society_user';
}
